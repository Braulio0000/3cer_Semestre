#include "perro.h"

Perro::Perro()
{
    //ctor
}

Perro::~Perro()
{
    //dtor
}
