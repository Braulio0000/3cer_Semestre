#include <iostream>
#include <stdlib.h>
#include <iostream>
#include "animal.h"
using namespace std;
using namespace std;

int main()
{
    Grifo Grifo1("grifo de fuego",11,"carnivoro","macho",2.5,"largo","rojo","afiladas","rojas","curvo");
    Grifo1.mostrarGrifo();
    return 0;
}
