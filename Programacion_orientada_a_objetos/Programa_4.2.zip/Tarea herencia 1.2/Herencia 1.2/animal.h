#ifndef ANIMAL_H
#define ANIMAL_H
#include <stdlib.h>
#include <iostream>
using namespace std;

class Animal
{
    public:
        Animal(string,int,string,string,float);
        void mostrarAnimal();
        virtual ~Animal();

    protected:

    private:
        string raza;
        int edad;
        string tipo;
        string sexo;
        float altura;

};

class Leon: virtual public Animal{
private:
    string tipoDePelo;
    string colorDelPelaje;

public:
    Leon(string,int,string,string,float,string,string);
    void mostrarLeon();


};
class Aguila: virtual public Animal
{
private:
    string tipoDePluma;
    string tipoDePico;
    string tipoDeGarras;
public:
    Aguila(string,int,string,string,float,string,string,string);
    void mostrarAguila();




};

class Grifo: public Leon , public Aguila{
    private:
    public:Grifo(string,int,string,string,float,string,string,string,string,string);
    void mostrarGrifo();

} ;
#endif // ANIMAL_H
