#include "animal.h"
#include <stdlib.h>
#include <iostream>
using namespace std;
Animal::Animal(string _raza,int _edad,string _tipo,string _sexo,float _altura)
{
    raza=_raza;
    edad=_edad;
    tipo=_tipo;
    sexo=_sexo;
    altura=_altura;
    //ctor
}
void Animal::mostrarAnimal()
{
    cout<<"raza: "<<raza<<endl;
    cout<<"edad:  "<<edad<<endl;
    cout<<"tipo: "<<tipo<<endl;
    cout<<"sexo: "<<sexo<<endl;
    cout<<"altura:  "<<altura<<endl;
}
Leon::Leon(string _raza,int _edad,string _tipo,string _sexo,float _altura,string _tipoDePelo,string _colorDelPelaje):Animal(_raza,_edad,_tipo,_sexo,_altura)
{
    tipoDePelo=_tipoDePelo;
    colorDelPelaje=_colorDelPelaje;

}

void Leon::mostrarLeon()
{
    mostrarAnimal();
    cout<<"tipoDePelo: "<<tipoDePelo<<endl;
    cout<<"colorDelPelaje:  "<<colorDelPelaje<<endl;
}

Aguila::Aguila(string _raza,int _edad,string _tipo,string _sexo,float _altura,string _tipoDePluma,string _tipoDePico,string _tipoDeGarras):Animal(_raza,_edad,_tipo,_sexo,_altura)
{
tipoDePluma=_tipoDePluma;
tipoDePico=_tipoDePico;
tipoDeGarras=_tipoDeGarras;
}
void Aguila::mostrarAguila(){
    mostrarAnimal();
    cout<<"tipoDePlumas: "<<tipoDePluma<<endl;
    cout<<"tipoDePico:  "<<tipoDePico<<endl;
    cout<<"tipoDeGarras: "<<tipoDeGarras<<endl;

}
Grifo::Grifo(string _raza, int _edad, string _tipo, string _sexo, float _altura, string _tipoDePelo, string _colorDelPelaje, string _tipoDePluma, string _tipoDePico,string _tipoDeGarras)
:Animal(string _raza,int _edad,string _tipo,string _sexo,float _altura),:Leon( _tipoDePelo , _colorDelPelaje ),:Aguila( _tipoDePluma , _tipoDePico , _tipoDeGarras )
    {}
void Grifo::MostrarGrifo(){
mostrarAnimal();
mostrarLeon();
MostrarAguila();

