#ifndef PERRO_H
#define PERRO_H


class
{
    public:
        Perro(string,int);
        virtual ~Perro();

    protected:

    private:
        string raza;
        int edad;

};
class


#endif // PERRO_H
