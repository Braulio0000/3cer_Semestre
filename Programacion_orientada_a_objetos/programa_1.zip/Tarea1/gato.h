#ifndef GATO_H
#define GATO_H
#include "iostream"
using namespace std;
class Gato
{
    public:

    Gato();
    string nombre;
    int edad;
    float altura;
    string sexo;
    string tipo_de_pelo;
    string raza;

    void duerme(void);
    void come(string);
    bool corre(string);




    protected:

    private:
};

#endif // GATO_H
