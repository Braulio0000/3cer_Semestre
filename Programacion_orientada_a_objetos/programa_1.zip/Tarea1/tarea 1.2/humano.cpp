#include "humano.h"

humano::humano()
{
nombre="pepe";
edad=18;
altura=1.87;
sexo="masculino";

    //ctor
}
void humano::duerme(void)
{
cout<<"a mimir"<<endl;
}
void humano::come(string comida)
{
    cout<<"estoy comiendo "<<comida<<endl;
}
bool humano::corre(string lugar)
{
    cout<<"estoy corriendo en:"<<lugar<<endl;
}
