#include <iostream>
#include "humano.h"
using namespace std;

int main()
{
    humano var1;
    cout<<var1.nombre<<endl;
    var1.duerme();
    var1.come("patatas");
    return 0;
}
