#ifndef HUMANO_H
#define HUMANO_H
#include <iostream>
 using namespace std;
class humano
{
    public:
        humano();
        string nombre;
        int edad;
        float altura;
        string sexo;



        void duerme (void);
        void come (string);
        bool corre(string);

    protected:

    private:
};

#endif // HUMANO_H
