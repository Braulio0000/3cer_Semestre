#include "gato.h"

Gato::Gato()
{
    nombre="whiskas";
    edad=3;
    altura=0.58;
    sexo="masculino";



    //ctor
}
void Gato::duerme (void)
{
    cout<<"Zzzzzzz"<<endl;

}
void Gato::come (string comida)
{
    cout<<"estoy comiendo:"<<comida<<endl;
}
bool Gato::corre(string objetivo )
{
    cout<<"el gato corre para"<<objetivo<<endl;
}
