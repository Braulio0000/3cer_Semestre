#include <iostream>
#include "gato.h"
using namespace std;

int main()
{
    Gato var1;
    cout<<var1.nombre<<endl;
        var1.duerme();
        var1.come("pescao");
        return 0;
}
