#ifndef CARRO_H
#define CARRO_H
#include <iostream>

using namespace std;
class carro
{
    public:
        carro();
        string modelo;
        string marca;
        string motor;
        string llantas;
        int salida;
        string color;
        string asiento;
        float peso ;


        void transporta (string);
        void gira (string);
        void frena (string);


    protected:

    private:
};

#endif // CARRO_H
