#include "carro.h"

carro::carro()
{
    marca="ram";
    modelo="t-rex";
    motor="v8 con supercargador";
    color="rojo";
    //ctor
}
void carro::transporta(string carga)
{
    cout<<"la camioneta transporta "<<carga<<endl;
}
void carro::gira(string giro)
{
    cout<<"el carro gira en "<<giro<<endl;
}
void carro::frena(string manera)
{
 cout<<"el carro freno de forma " <<manera<<endl;
}
