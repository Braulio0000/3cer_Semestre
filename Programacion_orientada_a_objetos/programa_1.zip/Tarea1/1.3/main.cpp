#include <iostream>
#include "carro.h"
using namespace std;

int main()
{
carro var1;
cout<<var1.modelo<<endl;
cout<<var1.marca<<endl;
var1.frena("muy rapida");
var1.gira("en u");
}
