#ifndef INGENIERO_H
#define INGENIERO_H
#include <string>
#include "persona.h"
#include <stdlib.h>
using namespace std;
class Ingeniero : public Persona
{
public:
    Ingeniero(const std::string &nombre, int edad, const std::string &direccion, const std::string &especialidad);
    ~Ingeniero();

    void introduccion() const override;
    void movimiento() const override;
    void hablar() const override;
    void trabajo() const override;

    const std::string &getespecialidad() const;

private:
    std::string especialidad;
};

#endif // INGENIERO_H
