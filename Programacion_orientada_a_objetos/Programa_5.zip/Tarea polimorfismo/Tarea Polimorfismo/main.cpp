#include <iostream>
#include "persona.h"
#include "estudiante.h"
#include "profesor.h"
#include "ingeniero.h"
#include <string>
#include <stdlib.h>
using namespace std;
int main()
{
    Persona persona("John Doe", 30, "123 Main St.");
    Estudiante estudiante("Jane Doe", 22, "456 Elm St.", "Computer Science");
    Profesor profesor("Jim Brown", 45, "789 Oak St.", "Mathematics");
    Ingeniero ingeniero("Sally Green", 35, "321 Pine St.", "Software");

    persona.introduccion();
    estudiante.introduccion();
    profesor.introduccion();
    ingeniero.introduccion();

    return 0;
}
