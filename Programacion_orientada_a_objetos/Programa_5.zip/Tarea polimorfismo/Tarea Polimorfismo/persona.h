#ifndef PERSONa_H
#define PERSONa_H
#include <string>
class Persona
{
public:
    Persona(const std::string &nombre, int edad, const std::string &direccion);
    virtual ~Persona();

    virtual void introduccion() const;
    virtual void movimiento() const;
    virtual void hablar() const;
    virtual void trabajo() const;

    const std::string &getnombre() const;
    int getedad() const;
    const std::string &getdireccion() const;

protected:
    std::string nombre;
    int edad;
    std::string direccion;
};

#endif // PERSONA_H
