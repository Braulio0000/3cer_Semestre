#include "persona.h"
#include <string>
#include <iostream>
#include <stdlib.h>

using namespace std;

Persona::Persona(const std::string &nombre, int edad, const std::string &direccion)
    : nombre(nombre), edad(edad), direccion(direccion)
{
}

Persona::~Persona()
{
}

const std::string &Persona::getnombre() const
{
    return nombre;
}

int Persona::getedad() const
{
    return edad;
}

const std::string &Persona::getdireccion() const
{
    return direccion;
}
void Persona::getintroduccion() const
{
    std::cout << "hola yo soy " << nombre << "tengo" << edad << " de edad y vivo en " << direccion << "." << std::endl;
}

void Persona::getmovimiento() const
{
    std::cout << nombre << " se mueve" << std::endl;
}

void Persona::gethablar() const
{
    std::cout << nombre << " esta hablando" << std::endl;
}

void Persona::gettrabajo() const
{
    std::cout << nombre << "esta trabajando" << std::endl;
}
