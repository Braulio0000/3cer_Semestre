#ifndef ESTUDIANTE_H
#define ESTUDIANTE_H
#include "persona.h"
#include <string>
#include <stdlib.h>
using namespace std;
class Estudiante : public Persona
{
public:
    Estudiante(const std::string &nombre, int edad, const std::string &direccion, const std::string &labor);
    ~Estudiante();

    void introduccion() const override;
    void movimiento() const override;
    void hablar() const override;
    void trabajo() const override;

    const std::string &getlabor() const;

private:
    std::string labor;
};

#endif // ESTUDIANTE_H
