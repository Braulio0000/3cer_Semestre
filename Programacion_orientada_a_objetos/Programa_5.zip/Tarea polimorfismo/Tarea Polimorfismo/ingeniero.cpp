#include "ingeniero.h"
#include <string>
#include <iostream>
#include <stdlib.h>
using namespace std;
Ingeniero::Ingeniero(const std::string &nombre, int edad, const std::string &direccion, const std::string &especialidad)
    : Persona(nombre, edad, direccion), especialidad(especialidad)
{
}

Ingeniero::~Ingeniero()
{
}

const std::string &Ingeniero::getespecialidad() const
{
    return especialidad;
}

void Ingeniero::introduccion() const
{
    std::cout << "hola yo soy " << getnombre() << ". tengo " << getedad() << " a�os de edad y mi especialidad es la " << especialidad << " en ingenieria,en  " << getdireccion() << "." << std::endl;
}

void Ingeniero::movimiento() const
{
    std::cout << getnombre() << " camina al laboratorio" << std::endl;
}

void Ingeniero::hablar() const
{
    std::cout << getnombre() << " hablan sobre la " << especialidad << " con sus compa�eros de la chamba" << std::endl;
}

void Ingeniero::trabajo() const
{
    std::cout << getnombre() << " esta dise�ando algo sobre la " << especialidad <<"en el sistema" << std::endl;
}
