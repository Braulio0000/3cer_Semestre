#include "profesor.h"
#include <string>
#include <iostream>
#include <stdlib.h>
using namespace std;
Profesor::Profesor(const std::string &nombre, int edad, const std::string &direccion, const std::string &materia)
    : Persona(nombre, edad, direccion), materia(materia)
{
}

Profesor::~Profesor()
{
}

const std::string &Profesor::getmateria() const
{
    return materia;
}

void Profesor::introduccion() const
{
    std::cout << "hola yo soy  " << getnombre() << "tengo " << getedad() << " a�os de edad y ense�o la materia de " << materia << " en el salon " << getdireccion() << "." << std::endl;
}

void Profesor::movimiento() const
{
    std::cout << getnombre() << " va hacia el salon" << std::endl;
}
 void Profesor:::hablar() const
{
    std::cout << getnombre() << " esta explicando sobre " << materia << "a sus estudiantes" << std::endl;
}

void Profesor:::trabajo() const
{
    std::cout << getnombre() << "esta acomodando su programa" << std::endl;
}
