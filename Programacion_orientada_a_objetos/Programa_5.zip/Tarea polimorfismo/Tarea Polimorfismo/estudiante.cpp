#include "estudiante.h"
#include <string>
#include <iostream>
#include <stdlib.h>
using namespace std;
Estudiante::Estudiante(const std::string &nombre, int edad, const std::string &direccion, const std::string &labor)
    : Persona(nombre, edad, direccion), labor(labor)
{
}

Estudiante::~Estudiante()
{
}

const std::string &Estudiante::getlabor() const
{
    return labor;
}

void Estudiante::introduccion() const
{
    std::cout << "hola yo soy " << getnombre() << " y tengo" << getedad() << " a�os de edad y soy estudiante en " << labor << " en " << getdireccion() << "." << std::endl;
}

void Estudiante::movimiento() const
{
    std::cout << getnombre() << " camina a la clase" << std::endl;
}

void Estudiante::hablar() const
{
    std::cout << getnombre() << "esta hablando sobre su " << labor << " con sus amigos" << std::endl;
}

void Estudiante::trabajo() const
{
    std::cout << getnombre() << " esta trabajando para los examenes " << std::endl;
}
