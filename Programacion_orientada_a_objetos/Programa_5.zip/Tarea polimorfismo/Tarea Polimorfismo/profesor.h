#ifndef PROFESOR_H
#define PROFESOR_H
#include <string>
#include "persona.h"
#include <stdlib.h>
using namespace std;
class Profesor : public Persona
{
public:
    Profesor(const std::string &nombre, int edad, const std::string &direccion, const std::string &materia);
    ~Profesor();

    void introduccion() const override;
    void movimiento() const override;
    void hablar() const override;
    void trabajo() const override;

    const std::string &getmateria() const;

private:
    std::string materia;
};

#endif // PROFESOR_H
