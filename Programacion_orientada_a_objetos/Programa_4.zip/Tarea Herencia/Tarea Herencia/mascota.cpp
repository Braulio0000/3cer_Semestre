#include "mascota.h"
#include <stdlib.h>
#include <string>
#include <iostream>
using namespace std;

Mascota::Mascota(string _propietario,int _edadMascota, string  _nombreMascota)
{
    propietario = _propietario;
    edadMascota = _edadMascota;
    nombreMascota = _nombreMascota;
    //ctor
}
void Mascota::mostrarMascota()
{

    cout<<"propietario: "<<propietario<<endl;
    cout<<"edadMascota: "<<edadMascota<<endl;
    cout<<"nombreMascota: "<<nombreMascota<<endl;



}
Perro::Perro(string _propietario,int _edadMascota,string _nombreMascota,string _raza,string _jugueteFavorito): Mascota(_propietario ,_edadMascota , _nombreMascota )
{
    raza= _raza;
    jugueteFavorito= _jugueteFavorito;

}

void Perro::mostrarPerro()
{
    mostrarMascota();
    cout<<"raza: "<<raza<<endl;
    cout<<"jugueteFavorito: "<<jugueteFavorito<<endl;

}





Mascota::~Mascota()
{
    //dtor
}
