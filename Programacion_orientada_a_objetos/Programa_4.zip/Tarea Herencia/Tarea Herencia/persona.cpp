#include "persona.h"
#include <stdlib.h>
#include <iostream>
using namespace std;
Persona::Persona(string _nombre,int _edad,float _altura,string _ocupacion)
{

    nombre = _nombre;
    edad = _edad;
    altura = _altura;
    ocupacion=_ocupacion;
}
void Persona::mostrarPersona(){
cout<<"nombre: "<<nombre<<endl;
cout<<"edad: "<<edad<<endl;
cout<<"altura: "<<altura<<endl;
cout<<"ocupacion:  "<<ocupacion<<endl;
}



Alumno::Alumno(string _nombre,int _edad,float _altura,string _ocupacion,string _codigoAlumno,float _calificacion):Persona( _nombre, _edad, _altura, _ocupacion)
{
codigoAlumno = _codigoAlumno;
calificacion = _calificacion;
}

void Alumno::mostrarAlumno(){
mostrarPersona();
cout<<"codigoAlumno: "<<codigoAlumno<<endl;
cout<<"calificacion: "<<calificacion<<endl;

}

Persona::~Persona()
{
    //dtor
}
