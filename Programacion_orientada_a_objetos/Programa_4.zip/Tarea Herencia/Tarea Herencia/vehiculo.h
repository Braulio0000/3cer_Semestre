#ifndef VEHICULO_H
#define VEHICULO_H
#include <string>
using namespace std;
class Vehiculo
{
public:
    Vehiculo(string,int,string);
    void mostrarVehiculo();
    virtual ~Vehiculo();

private:
    string titular;
    int fechaDeFabricacion;
    string tipo;
};
class Carro: public Vehiculo
{
private:
    string color;
    float kilometraje;
    string modelo;


public:
    Carro(string,int,string,string,float,string);
    void mostrarCarro();

};



#endif // VEHICULO_H
