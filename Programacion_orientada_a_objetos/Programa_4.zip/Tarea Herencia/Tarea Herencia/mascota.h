#ifndef MASCOTA_H
#define MASCOTA_H
#include <string>
using namespace std;

class Mascota
{
public:
    Mascota(string,int,string);
    void mostrarMascota();
    virtual ~Mascota();

protected:

private:
    string propietario;
    int edadMascota;
    string nombreMascota;

};

class Perro: public Mascota
{
private:
    string raza;
    string jugueteFavorito;
public:
    Perro(string,int,string,string,string);
    void mostrarPerro();


};

#endif // MASCOTA_H
