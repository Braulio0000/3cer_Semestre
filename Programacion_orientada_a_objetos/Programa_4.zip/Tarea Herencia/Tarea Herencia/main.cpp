#include <iostream>
#include "persona.h"
#include "mascota.h"
#include <stdlib.h>
#include <iostream>
#include "vehiculo.h"
using namespace std;

int main()
{
    cout<<"Datos de la persona:  " <<endl;
    Alumno Alumno1("Braulio",19,1.82,"estudiante","220178914",99.9);
    Alumno1.mostrarAlumno();
    cout<<"Daros de la mascota:  "<<endl;
    Perro Perro1("Braulio caz",6,"Bairon","Border collie","Pelota");
    Perro1.mostrarPerro();
    cout<<"Datos del Vehiculo:   "<<endl;
    Carro Carro1("Braulio Yael",2022,"Deportivo","azul",12000,"mustang shelby gt");
    Carro1.mostrarCarro();
}
