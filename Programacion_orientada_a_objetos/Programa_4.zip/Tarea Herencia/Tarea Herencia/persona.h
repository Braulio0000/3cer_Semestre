#ifndef PERSONA_H
#define PERSONA_H
#include <string>
using namespace std;
class Persona
{
public:
    Persona(string, int, float,string);
    void mostrarPersona();
    virtual ~Persona();

protected:

private:
    string nombre;
    int edad;
    float altura;
    string ocupacion;
};
class Alumno : public Persona
{
private:
    string codigoAlumno;
    float calificacion;
public:
    Alumno(string,int,float,string,string,float);
    void mostrarAlumno();







};


#endif // PERSONA_H
