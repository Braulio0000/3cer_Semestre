#include "vehiculo.h"
#include <stdlib.h>
#include <iostream>
using namespace std;
Vehiculo::Vehiculo(string _titular,int _fechaDeFabricacion,string _tipo)
{
    titular= _titular;
    fechaDeFabricacion= _fechaDeFabricacion;
    tipo= _tipo;

    //ctor
}
void Vehiculo::mostrarVehiculo()
{
    cout<<"titular: "<<titular<<endl;
    cout<<"fechaDeFabricacion: "<<fechaDeFabricacion<<endl;
    cout<<"tipo: "<<tipo<<endl;

}
Carro::Carro(string _titular,int fechaDeFabricacion_,string _tipo,string _color,float _kilometraje,string _modelo):Vehiculo(_titular,fechaDeFabricacion_,_tipo){
color= _color;
kilometraje= kilometraje;
modelo=_modelo;

}


void Carro::mostrarCarro(){
    mostrarVehiculo();
cout<<"color: "<<color<<endl;
cout<<"kilometraje: "<<kilometraje<<endl;
cout<<"modelo: "<<modelo<<endl;

}
Vehiculo::~Vehiculo()
{
    //dtor
}
