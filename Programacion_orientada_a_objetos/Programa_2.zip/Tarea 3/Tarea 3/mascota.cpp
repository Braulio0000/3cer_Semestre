#include "Mascota.h"

Mascota::Mascota(std::string n, std::string e, int a) : nombre(n), especie(e), edad(a) {}

std::string Mascota::getNombre() const { return nombre; }
std::string Mascota::getEspecie() const { return especie; }
int Mascota::getEdad() const { return edad; }

void Mascota::setNombre(std::string n) { nombre = n; }
void Mascota::setEspecie(std::string e) { especie = e; }
void Mascota::setEdad(int a) { edad = a; }

Mascota::~Mascota() {}
