#ifndef PERSONA_H
#define PERSONA_H

#include <string>

class Persona {
  private:
    std::string nombre;
    std::string apellido;
    std::string sexo;

  public:

    Persona(std::string n, std::string a, std::string s);


    std::string getNombre() const;
    std::string getApellido() const;
    std::string getSexo() const;

    void setNombre(std::string n);
    void setApellido(std::string a);
    void setSexo(std::string s);

    ~Persona();
};

#endif // PERSONA_H
