#include "Persona.h"

Persona::Persona(std::string n, std::string a, std::string s) : nombre(n), apellido(a), sexo(s) {}

std::string Persona::getNombre() const { return nombre; }
std::string Persona::getApellido() const { return apellido; }
std::string Persona::getSexo() const { return sexo; }

void Persona::setNombre(std::string n) { nombre = n; }
void Persona::setApellido(std::string a) { apellido = a; }
void Persona::setSexo(std::string s) { sexo = s; }

Persona::~Persona() {}
