#include <iostream>
#include "Persona.h"
#include "Mascota.h"

int main() {
  Persona persona("Braulio", "Carranza", "Masculino");


  std::cout << "Nombre: " << persona.getNombre() << std::endl;
  std::cout << "Apellido: " << persona.getApellido() << std::endl;
  std::cout << "Sexo: " << persona.getSexo() << std::endl;


  Mascota mascota("Bairon", "Perro", 5);


  std::cout << "Nombre: " << mascota.getNombre() << std::endl;
  std::cout << "Especie: " << mascota.getEspecie() << std::endl;
  std::cout << "Edad: " << mascota.getEdad() << std::endl;

  return 0;
}
