#ifndef MASCOTA_H
#define MASCOTA_H

#include <string>

class Mascota {
  private:
    std::string nombre;
    std::string especie;
    int edad;

  public:

    Mascota(std::string n, std::string e, int a);


    std::string getNombre() const;
    std::string getEspecie() const;
    int getEdad() const;


    void setNombre(std::string n);
    void setEspecie(std::string e);
    void setEdad(int a);

    ~Mascota();
};

#endif // MASCOTA_H
