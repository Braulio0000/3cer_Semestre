#include "Producto.h"
#include <iostream>

void Producto::mostrarInformacion() const {
    std::cout << "Nombre: " << nombre_ << ", Precio: " << precio_ << std::endl;
}

std::string Producto::get_nombre() const {
    return nombre_;
}

float Producto::get_precio() const {
    return precio_;
}

void Producto::set_nombre(std::string nombre) {
    nombre_ = nombre;
}

void Producto::set_precio(float precio) {
    precio_ = precio;
}
