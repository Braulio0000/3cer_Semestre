#ifndef PERECEDERO_H
#define PERECEDERO_H

#include "Producto.h"

class Perecedero : public Producto {
private:
    std::string fecha_caducidad_;

public:
    Perecedero(std::string nombre, float precio, std::string fecha_caducidad)
        : Producto(nombre, precio), fecha_caducidad_(fecha_caducidad) {}

    void mostrarInformacion() const override;

    ~Perecedero() {} // Destructor
};

#endif
