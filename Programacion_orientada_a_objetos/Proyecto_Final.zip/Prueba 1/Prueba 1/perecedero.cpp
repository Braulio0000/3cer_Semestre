#include "Perecedero.h"
#include <iostream>

void Perecedero::mostrarInformacion() const {
    std::cout << "Nombre: " << get_nombre() << ", Precio: " << get_precio() << ", Fecha de Caducidad: " << fecha_caducidad_ << std::endl;
}
