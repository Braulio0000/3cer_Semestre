#ifndef PRODUCTO_H
#define PRODUCTO_H

#include <string>

class Producto {
protected:
    std::string nombre_;
    float precio_;

public:
    Producto(std::string nombre, float precio) : nombre_(nombre), precio_(precio) {}

    virtual void mostrarInformacion() const;

    std::string get_nombre() const;
    float get_precio() const;

    void set_nombre(std::string nombre);
    void set_precio(float precio);

    virtual ~Producto() {} // Destructor
};

#endif
