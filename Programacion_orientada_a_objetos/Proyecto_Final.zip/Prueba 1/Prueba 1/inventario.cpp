#include "Inventario.h"
#include <iostream>

void Inventario::agregarProducto(std::shared_ptr<Producto> prod) {
    productos.push_back(std::move(prod));
}

void Inventario::mostrarProductos() const {
    for (const auto& prod : productos) {
        prod->mostrarInformacion();
    }
}

std::shared_ptr<Producto> Inventario::buscarProducto(std::string nombre) const {
    for (const auto& prod : productos) {
        if (prod->get_nombre() == nombre) {
            return prod;
        }
    }
    return nullptr;
}

void Inventario::eliminarProducto(std::string nombre) {
    for (auto it = productos.begin(); it != productos.end(); ++it) {
        if ((*it)->get_nombre() == nombre) {
            productos.erase(it);
            std::cout << "Producto eliminado correctamente." << std::endl;
            return;
        }
    }
    std::cout << "Producto no encontrado." << std::endl;
}

Inventario::~Inventario() {}
