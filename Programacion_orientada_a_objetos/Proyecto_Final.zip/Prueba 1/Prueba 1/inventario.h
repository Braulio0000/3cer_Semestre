#ifndef INVENTARIO_H
#define INVENTARIO_H

#include <vector>
#include <string>
#include "Producto.h"
#include "Perecedero.h"
#include <memory>

class Inventario {
private:
    std::vector<std::shared_ptr<Producto>> productos;

public:
    void agregarProducto(std::shared_ptr<Producto> prod);

    void mostrarProductos() const;

    std::shared_ptr<Producto> buscarProducto(std::string nombre) const;

    void eliminarProducto(std::string nombre);

    ~Inventario(); // Destructor
};

#endif
