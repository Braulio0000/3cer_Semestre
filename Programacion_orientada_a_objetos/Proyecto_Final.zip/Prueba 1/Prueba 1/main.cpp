#include "Inventario.h"
#include "Producto.h"
#include "Perecedero.h"
#include <iostream>
#include <string>
#include <memory>

int main() {
    Inventario inventario;
    int option;
    std::string nombre;
    float precio;
    std::string fechaCaducidad;
    std::shared_ptr<Producto> producto;
    std::shared_ptr<Producto> productoEncontrado;
    std::string confirmacion;

    do {
        std::cout << "\n1. Agregar producto\n2. Mostrar productos\n3. Buscar producto\n4. Eliminar producto\n5. Salir\n";
        std::cout << "Seleccione una opcion: ";
        std::cin >> option;

        switch (option) {
            case 1:
                std::cout << "Ingrese el nombre del producto: ";
                std::cin.ignore();
                std::getline(std::cin, nombre);
                std::cout << "Ingrese el precio del producto: ";
                std::cin >> precio;

                std::cout << "Ingrese la fecha de caducidad (dd-mm-yyyy) (si no es perecedero, deje en blanco): ";
                std::cin.ignore();
                std::getline(std::cin, fechaCaducidad);

                if (fechaCaducidad.empty()) {
                    producto = std::make_shared<Producto>(nombre, precio);
                } else {
                    producto = std::make_shared<Perecedero>(nombre, precio, fechaCaducidad);
                }

                inventario.agregarProducto(producto);
                break;
            case 2:
                inventario.mostrarProductos();
                break;
            case 3:
                std::cout << "Ingrese el nombre del producto a buscar: ";
                std::cin.ignore();
                std::getline(std::cin, nombre);
                productoEncontrado = inventario.buscarProducto(nombre);
                if (productoEncontrado != nullptr) {
                    productoEncontrado->mostrarInformacion();
                } else {
                    std::cout << "Producto no encontrado.\n";
                }
                break;
            case 4:
                std::cout << "Ingrese el nombre del producto a eliminar: ";
                std::cin.ignore();
                std::getline(std::cin, nombre);
                productoEncontrado = inventario.buscarProducto(nombre);
                if (productoEncontrado != nullptr) {
                    std::cout << "Estas seguro de que desea eliminar el producto (si/no): ";
                    std::cin >> confirmacion;
                    if (confirmacion == "si") {
                        inventario.eliminarProducto(nombre);
                        std::cout << "Producto eliminado correctamente.\n";
                    } else {
                        std::cout << "Operaci�n cancelada.\n";
                    }
                } else {
                    std::cout << "Producto no encontrado.\n";
                }
                break;
            case 5:
                std::cout << "adios\n";
                break;
            default:
                std::cout << "Opcion invalida. Intente de nuevo.\n";
        }
    } while (option != 5);

    return 0;
}
